﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using AntiXss.Models;
using Microsoft.Security.Application;

namespace AntiXss.Controllers
{
    public class PersonController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Save(PersonModel model)
        {
            //Sanitizer为AntiXss类库提供的静态类，用于过滤XSS代码
            model.Name = Sanitizer.GetSafeHtmlFragment(model.Name);
            //保存到数据库中
            return Content(model.Name);
        }
    }
}
