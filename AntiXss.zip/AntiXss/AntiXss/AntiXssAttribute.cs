﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.Mvc;
using Microsoft.Security.Application;

namespace AntiXss
{
    public class AntiXssAttribute :ValidationAttribute, IMetadataAware
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            //对于XSS攻击，只需要对string类型进行验证就可以了
            var str = value as string;
            if (!string.IsNullOrWhiteSpace(str) && 
                validationContext.ObjectInstance != null && !
                string.IsNullOrWhiteSpace(validationContext.MemberName))
            {
                str = Sanitizer.GetSafeHtmlFragment(str);
                PropertyInfo pi = validationContext.ObjectType.GetProperty(validationContext.MemberName,
                    BindingFlags.Public | BindingFlags.Instance);
                pi.SetValue(validationContext.ObjectInstance,str);
            }
            //由于这个类的目的并不是为了验证，所以返回验证成功
            return ValidationResult.Success;
        }

        public void OnMetadataCreated(ModelMetadata metadata)
        {
            //实际上AllowHtmlAttribute也是实现了接口IMetadataAware，在OnMetadataCreated
            //中使用了如下的代码
            metadata.RequestValidationEnabled = false;
        }
    }
}