﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.UI.WebControls;

namespace AntiXss
{
    public class AntiXssDataAnnotationsModelValidator:DataAnnotationsModelValidator
    {
        public AntiXssDataAnnotationsModelValidator(ModelMetadata metadata,ControllerContext context,AntiXssAttribute attribute)
            :base(metadata,context,attribute)
        { }

        public override IEnumerable<ModelValidationResult> Validate(object container)
        {
            var validationContext = new ValidationContext(container ?? base.Metadata.Model, null, null);
            validationContext.DisplayName = base.Metadata.GetDisplayName();
            validationContext.MemberName = base.Metadata.PropertyName;
            ValidationResult validationResult = this.Attribute.GetValidationResult(base.Metadata.Model, validationContext);
            yield break;
        }
    }
}